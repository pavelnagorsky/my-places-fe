export interface IModerationExcursionsFormContext {
  search: string;
  dateFrom?: string | Date | null;
  dateTo?: string | Date | null;
}
