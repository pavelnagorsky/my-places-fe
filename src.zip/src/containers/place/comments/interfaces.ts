export interface ICommentsFormContext {
  comment: string;
}
