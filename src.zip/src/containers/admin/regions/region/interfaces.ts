import { ICreateAdminTranslation } from "@/services/interfaces";

export interface IRegionFormContext {
  titleTranslations: ICreateAdminTranslation[];
}
