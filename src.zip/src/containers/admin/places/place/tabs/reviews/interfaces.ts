export interface IAdminReviewsFormContext {
  search: string;
}
