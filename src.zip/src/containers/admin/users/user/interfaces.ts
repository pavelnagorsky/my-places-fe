export interface IBlockUserForm {
  blockEndDate: string | Date;
  reason: string;
}

export interface IModeratorForm {
  phone: string;
  address: string;
}
