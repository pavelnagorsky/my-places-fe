export interface IPlaceCardForm {
  excursionDuration: number; // Minutes
  description: string;
}
