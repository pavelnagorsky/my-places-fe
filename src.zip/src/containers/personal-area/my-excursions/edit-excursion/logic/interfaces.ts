import { IExcursionBuilderForm } from "@/containers/excursion-builder/content/form/logic/interfaces";

export interface IEditExcursionForm extends IExcursionBuilderForm {
  updateTranslations: boolean;
}
