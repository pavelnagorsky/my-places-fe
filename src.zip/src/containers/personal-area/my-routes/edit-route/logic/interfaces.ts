import { IRouteBuilderForm } from "@/containers/route-builder/content/form/logic/interfaces";

export interface IEditRouteForm extends IRouteBuilderForm {}
