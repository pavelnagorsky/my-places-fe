export interface IMyFavouritesFormContext {
  search: string;
  dateFrom?: string | Date | null;
  dateTo?: string | Date | null;
}
