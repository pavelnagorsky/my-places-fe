export interface ISelect {
  id: number;
  label: string;
}
