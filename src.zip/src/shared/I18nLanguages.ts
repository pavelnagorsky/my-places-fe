const I18nLanguages = {
  ru: "ru",
  en: "en",
  be: "be",
};

export default I18nLanguages;
