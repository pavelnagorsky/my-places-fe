export enum LanguageIdsEnum {
  ru = 1,
  be = 2,
  en = 3,
}
