const websiteJsonld = () => {
    return {
        "@context": "http://schema.org",
        "@type": "WebSite",
        "name": "Знай свой край",
        "url": "https://my-places.by",
    };
};

export default websiteJsonld;