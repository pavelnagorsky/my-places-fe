const localStorageFields = {
  TOKEN: "TOKEN",
  SEARCH_CART: "SEARCH_CART",
};

export default localStorageFields;
