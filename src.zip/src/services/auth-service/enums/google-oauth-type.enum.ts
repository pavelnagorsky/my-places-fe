export enum GoogleOauthTypesEnum {
  OAUTH = "oauth",
  ONE_TAP = "one-tap",
}
