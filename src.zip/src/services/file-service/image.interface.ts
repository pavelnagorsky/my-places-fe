export interface IImage {
  id: number;
  url: string;
}
