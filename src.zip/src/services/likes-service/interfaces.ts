export interface ILikeExists {
  isLiked: boolean;
}
