export interface IPlaceType {
  id: number;
  title: string;
  commercial: boolean;
  image: string | null;
  image2: string | null;
}
