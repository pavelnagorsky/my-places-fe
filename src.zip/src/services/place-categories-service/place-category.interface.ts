export interface IPlaceCategory {
  id: number;
  title: string;
  image: string | null;
  image2: string | null;
}
