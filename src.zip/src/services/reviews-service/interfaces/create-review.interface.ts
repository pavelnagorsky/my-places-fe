export interface ICreateReview {
  title: string;
  description: string;
  placeId: number;
  imagesIds: number[];
}
