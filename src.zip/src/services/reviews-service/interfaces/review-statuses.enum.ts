export enum ReviewStatusesEnum {
  MODERATION = 0,
  APPROVED = 1,
  REJECTED = 2,
}
