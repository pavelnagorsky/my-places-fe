export interface ICreateSlug {
  id?: number;
  slug: string;
}
