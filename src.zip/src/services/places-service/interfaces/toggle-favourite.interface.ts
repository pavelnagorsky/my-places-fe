export interface IToggleFavourite {
  isActual: boolean;
}
