export interface IFavourite {
  id: number;
  placeTitle: string;
  placeSlug: string;
  placeId: number;
  actual: boolean;
  createdAt: string;
}
