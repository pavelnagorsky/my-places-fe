interface ISelectPlace {
  title: string;
  id: number;
}

export default ISelectPlace;
