export interface IPlaceSlug {
  id: number;
  slug: string;
}
