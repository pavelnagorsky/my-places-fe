export enum PlaceStatusesEnum {
  MODERATION = 0,
  APPROVED = 1,
  REJECTED = 2,
  NEEDS_PAYMENT = 3,
  COMMERCIAL_EXPIRED = 4,
}
