export interface IModeration {
  accept: boolean;
  feedback?: string;
}
