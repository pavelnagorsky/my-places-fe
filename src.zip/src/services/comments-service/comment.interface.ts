export interface IComment {
  id: number;
  authorUsername: string;
  authorId: number;
  text: string;
  createdAt: string;
}
