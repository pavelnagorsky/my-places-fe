export interface ISearchPlaceOption {
  id: number;

  title: string;

  slug: string;
}
