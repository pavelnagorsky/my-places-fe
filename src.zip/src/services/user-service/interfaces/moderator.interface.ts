export interface IModerator {
  id: number;
  userId: number;
  address: string;
  phone: string;
}
