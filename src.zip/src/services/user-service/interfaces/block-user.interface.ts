export interface IBlockUser {
  reason: string;
  blockEnd: string;
}
