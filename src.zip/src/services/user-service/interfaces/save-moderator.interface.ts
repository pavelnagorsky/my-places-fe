export interface ISaveModerator {
  address: string;
  phone: string;
}
