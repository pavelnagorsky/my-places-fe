export interface IUserSelect {
  id: number;
  userName: string;
}
